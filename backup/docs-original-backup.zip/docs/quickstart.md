---
sidebar_position: 2
---

# Quickstart Guide

:::note
This content has been consolidated with the [Introduction](./introduction.md) page. Please refer to the Introduction for getting started with MVMD.
:::

<meta http-equiv="refresh" content="0;url=./introduction.md" />
